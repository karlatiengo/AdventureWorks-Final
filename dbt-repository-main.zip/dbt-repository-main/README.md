### Introduction

Welcome to my project!

These files are used to transform data that is in the Data warehouse (Google BigQuery), preparing it to be used by a data viz tool. 

The data used in this project is data from the company AdventureWorks, a sample database provided by Microsoft.
